$(document).ready(() => {
    $(document).on("click",".delete", async function () {
        await Swal.fire({
            title: `Deleting ${$(this).attr("data-name")}`,
            icon: 'warning',
            html: `Напишете <u>${$(this).attr("data-name")}</u> за да продължите`,
            showCancelButton: true,
            input: "text",
            confirmButtonText: `ИЗТРИВАНЕ`,
            preConfirm: async (name) => {
                if (name.toLowerCase() !== $(this).attr("data-name").toLowerCase()) {
                    Swal.update({
                        title: "Отказано",
                        html: ""
                    });
                    await wait(1)
                } else {
                    await fetch(`/api/bots/${$(this).attr("data-id")}`, {method: "ИЗТРИВАНЕ"});
                    location.href = "/me";
                }
            }
        })
    })
})