$(document).ready(async function () {
  $('#like').click(async () => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: true
    })
    let { isConfirmed } = await swalWithBootstrapButtons.fire({
      title: 'Сигурни ли сте че искате да харесате този бот ?',
      text: "След това ще можете отново след цели 12 часа.",
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Добре'
    })
    if (!isConfirmed) return;
    let botid = location.href.split(location.host)[1].replace('/bots/like/', '').replace('/', '');
    let req = await fetch(`/api/like/${botid}`, {
      method: "PATCH",
      headers: { 'Content-Type': 'application/json' }
    })
    req = await req.json()
    if (req.success) {
      await swalWithBootstrapButtons.fire({
        title: 'Success',
        text: 'Вие успешно харесахте този бот!!',
        icon: 'success'
      })
      location.href = `/bots/${botid}`
    } else {
      let hours = 11 - Math.floor(req.time / 3600000);
      let minutes = 60 - Math.ceil((req.time  / 60000) % 60);
      await swalWithBootstrapButtons.fire({
        title: 'Грешка',
        text: `Можете да харесате този бот отново 
				след ${hours} часа и ${minutes} минути`,
        icon: 'error'
      })
      location.href = `/bots/${botid}`
    }
  })
})
